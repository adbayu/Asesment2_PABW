<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Produk</title>
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=poppins:400,500,600,700" rel="stylesheet" />
    <style>
    :root {
        --primary: #9F1521;
        --primary-soft: #c22632;
        --bg: #f9fafb;
        --card: #fff;
        --text: #1f2937;
        --muted: #6b7280;
        --border: #e5e7eb;
        --radius: 14px;
    }

    * {
        box-sizing: border-box;
        margin: 0;
        padding: 0;
    }

    body {
        min-height: 100vh;
        font-family: 'Poppins', system-ui, -apple-system, sans-serif;
        background: var(--bg);
        color: var(--text);
        padding: 28px;
    }

    .shell {
        width: min(680px, 100%);
        margin: 0 auto;
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: var(--radius);
        box-shadow: 0 20px 60px rgba(15, 23, 42, 0.08);
        padding: 24px;
        display: grid;
        gap: 16px;
    }

    .title {
        font-size: 22px;
        letter-spacing: -0.01em;
    }

    .muted {
        color: var(--muted);
    }

    form {
        display: grid;
        gap: 12px;
    }

    label {
        font-size: 14px;
        color: var(--muted);
        margin-bottom: 4px;
        display: block;
    }

    input,
    select,
    textarea {
        width: 100%;
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 12px 14px;
        font-size: 14px;
        color: var(--text);
        background: #fff;
    }

    textarea {
        min-height: 120px;
        resize: vertical;
    }

    input:focus,
    select:focus,
    textarea:focus {
        outline: none;
        border-color: var(--primary-soft);
        box-shadow: 0 0 0 3px rgba(159, 21, 33, 0.12);
    }

    .actions {
        display: flex;
        gap: 12px;
        flex-wrap: wrap;
    }

    .btn {
        padding: 11px 14px;
        border-radius: 10px;
        border: 1px solid transparent;
        font-weight: 700;
        cursor: pointer;
        text-decoration: none;
        color: #fff;
        background: var(--primary);
        transition: transform 120ms ease, box-shadow 120ms ease, background 120ms ease;
    }

    .btn:hover {
        background: var(--primary-soft);
        transform: translateY(-1px);
        box-shadow: 0 12px 30px rgba(159, 21, 33, 0.18);
    }

    .btn.secondary {
        background: #fff;
        color: var(--primary);
        border-color: var(--border);
        box-shadow: none;
    }

    .btn.secondary:hover {
        border-color: var(--primary);
        color: var(--primary-soft);
    }

    .error {
        background: #fef2f2;
        border: 1px solid #fecdd3;
        color: #b91c1c;
        padding: 10px 12px;
        border-radius: 10px;
        font-size: 14px;
    }

    @media (max-width:640px) {
        body {
            padding: 16px;
        }
    }
    </style>
</head>

<body>
    <div class="shell">
        <div>
            <h1 class="title">Edit Produk</h1>
            <p class="muted">Perbarui informasi produk.</p>
        </div>

        <?php if($errors->any()): ?>
        <div class="error"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('seller.products.update', $product)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div>
                <label for="name">Nama Produk</label>
                <input type="text" id="name" name="name" value="<?php echo e(old('name', $product->name)); ?>" required>
            </div>
            <div>
                <label for="price">Harga</label>
                <input type="number" id="price" name="price" value="<?php echo e(old('price', $product->price)); ?>" min="0"
                    required>
            </div>
            <div>
                <label for="condition">Kondisi</label>
                <select id="condition" name="condition" required>
                    <option value="">-- Pilih kondisi --</option>
                    <option value="baru" <?php if(old('condition', $product->condition) === 'baru'): echo 'selected'; endif; ?>>Baru</option>
                    <option value="bekas" <?php if(old('condition', $product->condition) === 'bekas'): echo 'selected'; endif; ?>>Bekas</option>
                </select>
            </div>
            <div>
                <label for="description">Deskripsi</label>
                <textarea id="description" name="description"><?php echo e(old('description', $product->description)); ?></textarea>
            </div>
            <div class="actions">
                <a class="btn secondary" href="<?php echo e(route('seller.products.index')); ?>">Batal</a>
                <button type="submit" class="btn">Simpan Perubahan</button>
            </div>
        </form>
    </div>
</body>

</html><?php /**PATH C:\Users\Andi bayu hanggoro\Desktop\Sem 3\PABW\Assesment 3\Asesment2_PABW\resources\views/seller/products/edit.blade.php ENDPATH**/ ?>